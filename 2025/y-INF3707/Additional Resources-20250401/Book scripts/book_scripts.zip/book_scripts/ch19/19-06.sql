USE ap;

SELECT * 
FROM vendor_contacts;